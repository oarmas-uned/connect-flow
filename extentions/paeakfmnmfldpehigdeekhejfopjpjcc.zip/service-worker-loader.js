import './assets/index.ts-Cs0Qdz_C.js';
import './src/automation/background.js';
