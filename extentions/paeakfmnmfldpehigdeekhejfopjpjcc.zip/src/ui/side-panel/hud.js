// HUD bar mailto routing.
// Side-panel pages don't reliably dispatch <a href="mailto:..."> to the system
// mail handler when clicked. Funnel those clicks through chrome.tabs.create so
// Chrome opens them the same way it does from a regular tab.

const links = document.querySelectorAll('a.hud-link[href^="mailto:"]');
for (const link of links) {
  link.addEventListener('click', (event) => {
    event.preventDefault();
    const url = link.getAttribute('href');
    if (!url) return;
    if (typeof chrome !== 'undefined' && chrome.tabs && chrome.tabs.create) {
      chrome.tabs.create({ url });
    } else {
      window.open(url, '_blank');
    }
  });
}
