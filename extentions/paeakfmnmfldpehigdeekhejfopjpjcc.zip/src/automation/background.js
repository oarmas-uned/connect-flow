/**
 * Flow Automata — service-worker side of the Angular-UI engine.
 *
 * Imported by service-worker-loader.js right after the frozen worker bundle
 * (assets/index.ts-*.js), which this file leaves untouched. That bundle's
 * runtime.onMessage listener returns false for any type it does not know and
 * never answers it, and the side panel's listener ignores unknown types too,
 * so a type handled here is answered here alone.
 *
 *   in  FA_KEEP_TAB_LOADED {keep}   content.js, when a batch starts (true)
 *                                   and when it ends, however it ends (false)
 */
(() => {
  'use strict';

  /**
   * Keep the batch's Flow tab from being discarded while the batch runs.
   *
   * Chrome discards background tabs to save memory and reloads them when they
   * are next shown, which throws away every script in the page. OBSERVED
   * 2026-09-15: a Flow tab left hidden behind another window changed its tab
   * id and stopped answering until it was reloaded. A batch in that tab dies
   * mid-prompt with nothing reported. `autoDiscardable: false` is Chrome's own
   * switch for this; it is set for the length of a run and handed back
   * afterwards, the same way the zoom is.
   */
  chrome.runtime.onMessage.addListener((msg, sender, respond) => {
    if (!msg || msg.type !== 'FA_KEEP_TAB_LOADED') return false;
    const tabId = sender && sender.tab && sender.tab.id;
    if (typeof tabId !== 'number') {
      respond({ success: false, error: 'FA_KEEP_TAB_LOADED has to come from a tab' });
      return false;
    }
    chrome.tabs.update(tabId, { autoDiscardable: !msg.keep }).then(
      () => respond({ success: true }),
      (e) => respond({ success: false, error: String((e && e.message) || e) })
    );
    return true;
  });
})();
